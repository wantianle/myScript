from typing import Union
import logging
import json
import os
import shutil
import time
import subprocess
from alive_progress import alive_bar
# from core.session import AppSession
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional
from utils import handles


class RecordDownloader:
    def __init__(self, session):
        self.ctx = session.ctx
        self.recorder = session.recorder
        self.remote_user = self.ctx.config["remote"]["user"]
        self.remote_ip = self.ctx.config["remote"]["ip"]

    @property
    def mode(self):
        return self.ctx.config["env"]["mode"]
    @property
    def dest_root(self):
        return Path(self.ctx.config["host"]["dest_root"])

    def get_file_size(self, path: str) -> int:
        """获取文件大小（本地或远程）"""
        if self.mode == 3:
            stat_cmd = f"ssh {self.remote_user}@{self.remote_ip} 'stat -c %s {path}'"
            res = subprocess.run(stat_cmd, shell=True, capture_output=True, text=True)
            return int(res.stdout.strip()) if res.returncode == 0 else 0
        else:
            p = Path(path)
            return p.stat().st_size if p.exists() else 0

    def cleanup_file(self, target_path: Union[str, Path], file_list: Optional[List[str]] = None):
        """
        删除源端的中间文件
        """
        target_path = Path(target_path)
        if file_list:
            whitelist = set(file_list) | {"version.json", "README.md"}
            for item in target_path.iterdir():
                if item.is_file() and item.name not in whitelist:
                    item.unlink()
        else:
            try:
                if self.mode == 3:
                    rm_cmd = (
                        f"ssh {self.remote_user}@{self.remote_ip} 'rm -f {target_path}'"
                    )
                    subprocess.run(rm_cmd, shell=True, capture_output=True)
                else:
                    p = Path(target_path)
                    if p.exists():
                        p.unlink()
            except Exception as e:
                logging.warning(f"清理源端文件失败: {target_path}, 错误: {e}")

    def save_contract(self, task, save_dir, file_infos):
        """保存元数据，实现信息透传"""
        tag_dir = save_dir.parent
        meta_path = tag_dir / "meta.json"

        dt_tag = handles.str_to_time(task["time"])
        bf, af = int(self.ctx.config["logic"]["before"]), int(
            self.ctx.config["logic"]["after"]
        )

        contract = {
            "tag_info": {
                "name": task["name"],
                "time": task["time"],
                "offset_bf": bf,
                "offset_af": af,
                "abs_start": (dt_tag - timedelta(seconds=bf)).isoformat(),
                "abs_end": (dt_tag + timedelta(seconds=af)).isoformat(),
            },
            "vehicle": self.ctx.vehicle,
            "date": self.ctx.target_date,
            "last_update": {},
            "files": {},
        }
        if meta_path.exists():
            try:
                old_contract = json.loads(meta_path.read_text(encoding="utf-8"))
                contract["last_update"] = old_contract["last_update"]
                contract["files"] = old_contract["files"]
            except:
                logging.warning("元数据文件损坏，执行全量重写")
        current_soc = self.ctx.config["logic"]["soc"]
        contract["files"][current_soc] = [Path(f[1]).name for f in file_infos]
        contract["last_update"][current_soc] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        meta_path.write_text(json.dumps(contract, indent=4, ensure_ascii=False))

    def post_process_task(self, task, save_dir, file_infos):
        """生成元数据文件、 README 和 version.json"""
        self.save_contract(task, save_dir, file_infos)

        # 同步 version.json
        src_dir = Path(file_infos[0][0]).parent
        v_src = src_dir / "version.json"
        v_dest = save_dir / "version.json"

        try:
            if self.mode == 3:
                remote_src = f"{self.remote_user}@{self.remote_ip}:{v_src}"
                down_cmd = ["scp", "-q", "-o", remote_src, v_dest]

                env_c = os.environ.copy()
                env_c["LC_ALL"] = "C"

                result = subprocess.run(down_cmd,env=env_c, capture_output=True, text=True)

                if result.returncode != 0:
                    print(f"拷贝失败: {result.stderr}")
            else:
                if os.path.exists(v_src):
                    shutil.copy2(v_src, v_dest)
        except Exception as e:
            logging.warning(f"拷贝 {task['name']}: version.json 文件失败：{e}")

        # 生成 README
        v_content = v_dest.read_text() if v_dest.exists() else "N/A"
        records_str = " ".join([Path(f[1]).name for f in file_infos])
        readme_content = f"""- **tag：** {task['time']} {task['name']}
- **问题描述：**
> 填写补充描述
- **预期结果：**
> 填写正确情况
- **实际结果：**
> 填写错误情况
- **车辆软硬件信息：**
```json
{v_content}
```
- **数据路径：**
```bash
{self.ctx.config['host']['nas_root']}/{self.ctx.target_date}/{self.ctx.vehicle}/{task['name']}/{self.ctx.config['logic']['soc']}
```
- **数据时刻：**
```bash
{records_str}
```
- **回播命令：**
```bash
cd {save_dir}
cyber_recorder play -l -f {records_str}
```
"""
        readme_path = save_dir / "README.md"
        readme_path.write_text(readme_content, encoding="utf-8")

    def _process_single_file(self, src, dest, start, end, blacklist):
        """
        处理单个文件：分模式决策
        """

        if self.mode != 3:
            # if dest.exists(): return

            return self.recorder.split_async(
                host_in=str(src),
                host_out=str(dest),
                start_dt=start,
                end_dt=end,
                blacklist=blacklist,
            )
        else:
            remote_split_path = f"{src}.split"

            self.recorder.split(
                host_in=str(src),
                host_out=remote_split_path,
                start_dt=start,
                end_dt=end,
                blacklist=blacklist,
            )

            env_c = os.environ.copy()
            env_c["LC_ALL"] = "C"
            remote_uri = f"{self.remote_user}@{self.remote_ip}:{remote_split_path}"
            subprocess.run(["scp", "-q", remote_uri, str(dest.parent)],env=env_c, check=True)

            self.cleanup_file(remote_split_path)

    def download_record(self, task_list):
        flat_tasks = []
        for task in task_list:
            if not task["paths"]: continue
            folder_name = f"{int(task['id']):02d}.{task['name']}"
            soc_name = self.ctx.config["logic"]["soc"].strip("/")
            save_dir = self.dest_root / self.ctx.target_date[:8] / self.ctx.vehicle / folder_name / soc_name
            save_dir.mkdir(parents=True, exist_ok=True)

            for p in task["paths"]:
                flat_tasks.append({
                    "src": Path(p),
                    "dest": save_dir / (Path(p).name + ".split"),
                    "task_ref": task,
                    "save_dir": save_dir
                })

        print(f"\n>>> 准备同步 {len(flat_tasks)} 个 Record 片段...")
        with alive_bar(len(flat_tasks), title="Progress", theme="classic") as bar:
            cur_id = None
            cur_files = []
            cur_task = None
            cur_dir = None

            for item in flat_tasks:
                src, dest, task = item["src"], item["dest"], item["task_ref"]
                # 如果当前处理的 ID 和记录的 ID 不同，且记录不为空，说明【上一个任务】结束了
                if cur_id is not None and task["id"] != cur_id:
                    self.post_process_task(
                        cur_task, cur_dir, cur_files
                    )
                    cur_files = []

                cur_id = task["id"]
                cur_task = task
                cur_dir = item["save_dir"]

                bar.text = f"-> [Tag: {task['name'][:15]}]"
                self._execute_and_monitor(src, dest, task, bar)
                cur_files.append((str(src),str(dest)))
                bar()

            if cur_task and cur_files:
                bar.text = f"-> [Post-Process] Finalizing last task: {cur_task['name'][:15]}..."
                self.post_process_task(
                    cur_task, cur_dir, cur_files
                )

        print("\n>>> 所有同步任务已完成！")

    def _execute_and_monitor(self, src, dest, task, bar):
        """执行并实时监控文件增长"""
        if dest.exists():
            return

        tag_dt = handles.str_to_time(task["time"])
        t_start = tag_dt - timedelta(seconds=int(self.ctx.config["logic"]["before"]))
        t_end = tag_dt + timedelta(seconds=int(self.ctx.config["logic"]["after"]))
        blacklist = self.ctx.config["logic"].get("blacklist", [])

        proc = self._process_single_file(src, dest, t_start, t_end, blacklist)

        if proc:
            while proc.poll() is None:
                if dest.exists():
                    size_mb = dest.stat().st_size / (1024 * 1024)
                    bar.text = f"-> {task['name'][:10]}.. | size: {size_mb:.1f}MB"
                time.sleep(0.1)

            # 检查退出状态
            if proc.returncode != 0:
                logging.error(f"切片失败: {src.name}")
