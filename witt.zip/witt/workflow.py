from core.session import AppSession
import parser
from utils import handles
from pathlib import Path
import logging

def full_progress(session: AppSession):
    parser.get_basic_params(session.ctx.config)
    parser.get_path_params(session.ctx.config)
    try:
        session.record_query()
        task_list = handles.parse_manifest(session.ctx.manifest_path)
        selected_list = parser.get_selected_indices(task_list)
        valid_tasks = [t for t in selected_list if t.get("paths")]

        if input("是否压缩 Record? [y/N] (回车跳过): ").lower() == "y":
            session.record_compress(Path(valid_tasks[0]["paths"][0]))

        if not valid_tasks: logging.error("所选序号无效"); return
        session.record_split(selected_list)
        if input("\n是否立即回播数据? [y/N] (回车跳过): ").lower() == "y":
            session.task_play()
    except Exception as e:
        logging.error(f"全流程执行失败: {e}")
        raise e
        # logging.debug(traceback.format_exc())
